{
    'name': 'Mi modulo personalizado 3',
    'version': '1.0',
    'depends': ['base'],
    'author': 'Everdev',
    'description': 'Módulo para mostrar el funcionamiento de como se crea un modulo.',
    'data': [
      'views/ticket_views.xml',
      'views/menu_views.xml'
    ],
    'installable': True,
    'application': True,
}
